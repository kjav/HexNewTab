### Hex Color Clock

A simple program that changes the the current time into a hexadecimal color value which is then used as a background color. It updates every second.

[View the live version here](http://saadq.github.io/Hex-Color-Clock/)