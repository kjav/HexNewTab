This extends the 'Hex-Color-Clock' created by saadq (https://github.com/saadq/Hex-Color-Clock), adding weather data from the open weather map.
